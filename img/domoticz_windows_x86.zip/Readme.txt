To install a new version/update just run the installer again.

DO NOT UNINSTALL, this will delete everything! (Unless you want so...)